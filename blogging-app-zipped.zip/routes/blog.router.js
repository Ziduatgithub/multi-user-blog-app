const express = require("express");
const blogModel = require("../models/blog.model");
const blogRouter = express.Router();

const authUser = (req, res, next) => {
  if (req.session.isAuth) {
    next();
  } else {
    res.redirect("/login");
  }
};

blogRouter.get("/dashboard/blogs/newBlog", authUser, (req, res) => {
  res.render("newBlog");
});
blogRouter.get("/dashboard/blogs", authUser, async (req, res) => {
  const blogs = await blogModel.find().sort({
    createdAt: "desc",
  });

  res.render("blogs", { blogs: blogs });
});
blogRouter.get("/dashboard/blogs/:id", async (req, res) => {
  const blog = await blogModel.findById(req.params.id);
  res.render("blog", { blog: blog });
});
blogRouter.get("blogs/:id", async (req, res) => {
  const blog = await blogModel.findById(req.params.id);
  res.render("blog", { blog: blog });
});
// blogRouter.post("/dashboard/newBlog", async (req, res) => {
//   const { title, author, content, createdAt } = req.body;
//   const blog = blogModel.create({
//     title,
//     author,
//     createdAt,
//     content,
//   });
//   await blog.save();
//   res.redirect(`/${blog.id}`);
// });
module.exports = blogRouter;
